from da.compiler.ui import *

print(dafile_to_pystr("await.da"))
